## LAB1: COLLEGE MANAGEMENT SYSTEM
    Class Diagram
    Statechart Diagram
    Usecase Diagram
    Sequence Diagram
    Activity Diagram
## LAB2: HOSTEL MANAGEMENT SYSTEM
    Class Diagram
    Statechart Diagram
    Usecase Diagram
    Sequence Diagram
    Activity Diagram
## LAB3: STOCK MANAGEMENT SYSTEM
    Class Diagram
    Statechart Diagram
    Usecase Diagram
    Sequence Diagram
    Activity Diagram
## LAB4: COFFEE VENDING SYSTEM
    Class Diagram
    Statechart Diagram
    Usecase Diagram
    Sequence Diagram
    Activity Diagram
## LAB5: ONLINE SHOPPING SYSTEM
    Class Diagram
    Statechart Diagram
    Usecase Diagram
    Sequence Diagram
    Activity Diagram
## LAB6: RAILWAY RESERVATION SYSTEM
    Class Diagram
    Statechart Diagram
    Usecase Diagram
    Sequence Diagram
    Activity Diagram
## LAB7: GRAPHICS EDITOR SYSTEM
    Class Diagram
    Statechart Diagram
    Usecase Diagram
    Sequence Diagram
    Activity Diagram
